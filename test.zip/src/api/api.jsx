import axios from "axios";

const API_URL = "http://20.244.56.144/test";

export const fetchProducts = async (filters, sort, page) => {
  const { company, category, minPrice, maxPrice } = filters;
  const response = await axios.get(
    `${API_URL}/companies/${company}/categories/${category}/products/top-10`,
    {
      params: {
        minPrice,
        maxPrice,
        sort,
        page,
      },
    }
  );
  return response.data;
};

export const fetchProductById = async (id) => {
  const response = await axios.get(`${API_URL}/products/${id}`);
  return response.data;
};
