import { createTheme } from "@mui/material/styles";

const theme = createTheme({
  palette: {
    primary: {
      main: "#0070f3",
    },
    secondary: {
      main: "#ff4081",
    },
    background: {
      default: "#f5f5f5",
    },
  },
  typography: {
    h5: {
      fontWeight: 700,
    },
    body2: {
      color: "#6e6e6e",
    },
  },
});

export default theme;
