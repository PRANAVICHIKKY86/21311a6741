import React, { useState } from "react";
import {
  Box,
  Pagination,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TableSortLabel,
  IconButton,
  TextField,
} from "@mui/material";
import VisibilityIcon from "@mui/icons-material/Visibility";
import MoreVertIcon from "@mui/icons-material/MoreVert";
import "./table.css";
import { DownloadOutlined } from "@ant-design/icons";
import ColorsList from "./ColorList";
import EditDeleteActionColumn from "./editDeleteActionColumn";
import CustomerActionCell from "./customerActionColumn";
import OrderActionCell from "./orderActionColumn";

const TableView = ({
  data = [],
  columns = [],
  editedData,
  setEditedData,
  handleUpdate,
  apiEndpoint,
}) => {
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(10);
  const [searchQuery, setSearchQuery] = useState("");
  const [sortOrder, setSortOrder] = useState("asc");
  const [sortColumn, setSortColumn] = useState(
    columns && columns.length ? columns[0].field : ""
  );
  const colors = ["#000000", "#9F9F9F", "#882853", "#283988", "#E98F8F"];

  const handleViewClick = (row) => {
    // Handle view click action here
  };

  const handleSortClick = (column) => {
    if (column === "edit") return;

    if (column === sortColumn) {
      setSortOrder(sortOrder === "asc" ? "desc" : "asc");
    } else {
      setSortColumn(column);
      setSortOrder("asc");
    }
  };

  const handleSearchChange = (e) => {
    setSearchQuery(e.target.value);
    setCurrentPage(1);
  };

  const filteredData = data.filter((row) => {
    const searchValue = searchQuery.toLowerCase();
    return columns.some((column) => {
      const columnValue = row[column.field];
      if (typeof columnValue === "string") {
        return columnValue.toLowerCase().includes(searchValue);
      } else if (typeof columnValue === "number") {
        return columnValue.toString().includes(searchValue);
      }
      return false;
    });
  });

  const sortedData = filteredData.slice().sort((a, b) => {
    const valueA = a[sortColumn];
    const valueB = b[sortColumn];
    if (typeof valueA === "string" && typeof valueB === "string") {
      return sortOrder === "asc"
        ? valueA.localeCompare(valueB)
        : valueB.localeCompare(valueA);
    } else {
      return sortOrder === "asc" ? valueA - valueB : valueB - valueA;
    }
  });

  const indexOfLastItem = currentPage * itemsPerPage;
  const indexOfFirstItem = indexOfLastItem - itemsPerPage;
  const currentItems = sortedData.slice(indexOfFirstItem, indexOfLastItem);

  return (
    <div>
      <Box className="Table-card">
        <TextField
          placeholder="Search here..."
          variant="standard"
          value={searchQuery}
          onChange={handleSearchChange}
          style={{ marginBottom: "10px" }}
        />
        <div
          style={{ overflowY: "auto", maxHeight: "38rem" }}
          className="table-container"
        >
          <Table stickyHeader>
            <TableHead>
              <TableRow>
                {columns.map((head) => (
                  <TableCell
                    key={head.field}
                    sx={{ backgroundColor: "#00B4D826", fontWeight: "bold" }}
                    className="tablecell"
                  >
                    <TableSortLabel
                      active={sortColumn === head.field}
                      direction={sortOrder}
                      onClick={() => handleSortClick(head.field)}
                    >
                      {head.header}
                    </TableSortLabel>
                  </TableCell>
                ))}
              </TableRow>
            </TableHead>

            <TableBody>
              {currentItems.map((row) => (
                <TableRow key={row.id}>
                  {columns.map((col) => (
                    <TableCell key={col.field} className="tablecell">
                      {col.field === "customerAction" ? (
                        <CustomerActionCell
                          row={row}
                          handleViewClick={handleViewClick}
                        />
                      ) : col.field === "orderAction" ? (
                        <OrderActionCell
                          row={row}
                          handleViewClick={handleViewClick}
                        />
                      ) : col.field === "availableColors" ? (
                        <ColorsList colors={row.colors} />
                      ) : col.field === "brandeditdeleteaction" ? (
                        <EditDeleteActionColumn
                          row={row}
                          handleViewClick={handleViewClick}
                          apiEndpoint="/brand"
                          Title="Brand"
                        />
                      ) : col.field === "materialeditdeleteaction" ? (
                        <EditDeleteActionColumn
                          row={row}
                          handleViewClick={handleViewClick}
                          apiEndpoint="/material"
                          Title="Material"
                        />
                      ) : col.field === "categoryeditdeleteaction" ? (
                        <EditDeleteActionColumn
                          row={row}
                          handleViewClick={handleViewClick}
                          apiEndpoint="/category"
                          Title="Category"
                        />
                      ) : col.field === "manufacturereditdeleteaction" ? (
                        <EditDeleteActionColumn
                          row={row}
                          handleViewClick={handleViewClick}
                          apiEndpoint="/manufacturer"
                          Title="Manufacturer"
                        />
                      ) : col.field === "producteditdeleteaction" ? (
                        <EditDeleteActionColumn
                          row={row}
                          handleViewClick={handleViewClick}
                          apiEndpoint="/product"
                          Title="Category"
                        />
                      ) : (
                        row[col.field]
                      )}
                    </TableCell>
                  ))}
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
        {data.length === 0 && <p>No data found</p>}
        <Pagination
          className="pagination-css"
          count={Math.ceil(sortedData.length / itemsPerPage)}
          page={currentPage}
          onChange={(event, page) => setCurrentPage(page)}
        />
      </Box>
    </div>
  );
};

export default TableView;
