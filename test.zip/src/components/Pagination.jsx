import React from "react";
import { Pagination } from "@mui/material";

const PaginationComponent = ({ count, page, setPage }) => {
  const handleChange = (event, value) => {
    setPage(value);
  };

  return <Pagination count={count} page={page} onChange={handleChange} />;
};

export default PaginationComponent;
