import React from "react";
import { FormControl, InputLabel, Select, MenuItem } from "@mui/material";

const Sort = ({ sort, setSort }) => {
  const handleChange = (e) => {
    setSort(e.target.value);
  };

  return (
    <FormControl>
      <InputLabel>Sort By</InputLabel>
      <Select value={sort} onChange={handleChange}>
        <MenuItem value="price">Price</MenuItem>
        <MenuItem value="rating">Rating</MenuItem>
        <MenuItem value="discount">Discount</MenuItem>
      </Select>
    </FormControl>
  );
};

export default Sort;
